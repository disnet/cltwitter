java -cp lib/'*' org.mozilla.javascript.tools.shell.Main main.js
