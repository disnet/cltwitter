java -cp lib/js.jar:lib/twitter4j.jar:lib/jline.jar org.mozilla.javascript.tools.shell.Main -f run_tests.js
