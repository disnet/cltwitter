cltwitter is a script that allows you to run filters written in javascript on twitter streams.

USAGE:
You'll need to modify config.properties to use your twitter username/password and which filters you want to run. 

If you want to write your own filters, just add them to src/filters.js

Once you have that ready just launch run.sh
